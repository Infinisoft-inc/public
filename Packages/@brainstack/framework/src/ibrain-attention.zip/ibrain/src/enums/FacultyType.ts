export enum FacultyType {
    Judgment = 'Judgment',
    Compassion = 'Compassion',
    Memory = 'Memory',
    Attention = 'Attention',
    Perception = 'Perception',
    Consciousness = 'Consciousness',
    Speech = 'Speech',
    Thought = 'Thought',
    Emotion = 'Emotion',
    Desire = 'Desire',
    Imagination = 'Imagination',
    Reasoning = 'Reasoning'
  }
  