export enum ExperienceType {
  Sensory = 'Sensory',
  Emotional = 'Emotional',
  Cognitive = 'Cognitive',
  Perceptual = 'Perceptual',
  Aesthetic = 'Aesthetic',
  Spiritual = 'Spiritual',
  Social = 'Social',
  AlteredState = 'AlteredState'
}
