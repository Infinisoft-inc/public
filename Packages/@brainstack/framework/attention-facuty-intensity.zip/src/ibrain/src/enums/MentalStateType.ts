export enum MentalStateType {
    Emotion = 'Emotion',
    Cognitive = 'Cognitive',
    Perceptual = 'Perceptual',
    Motivational = 'Motivational',
    Attentional = 'Attentional',
    Consciousness = 'Consciousness',
    Social = 'Social',
    Imaginative = 'Imaginative',
    Introspective = 'Introspective',
    Spiritual = 'Spiritual',
    Evaluative = 'Evaluative',
    Aesthetic = 'Aesthetic',
    Metacognitive = 'Metacognitive'
  }
  