export enum AttentionalShiftType {
    Overt = 'Overt (with eye movements)',
    Covert = 'Covert (without eye movements)'
  }
  