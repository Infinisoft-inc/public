export enum AttentionalControl {
    Voluntary = 'Voluntary (Endogenous)',
    Automatic = 'Automatic (Exogenous)'
  }
  